<?php
				

				
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://hack.leakstation.in' );
define('STYLESHEETS_URL', '//hack.leakstation.in' );
error_reporting(1);
date_default_timezone_set('Asia/Kolkata');

return [
  'db' => [
    'name'    =>  'leakeclj_hack' ,
    'host'    =>  'localhost',
    'user'    =>  'leakeclj_hack' ,
    'pass'    =>  'QV@e96XDS2}&' ,
    'charset' =>  'utf8mb4' 
  ]
];

?>