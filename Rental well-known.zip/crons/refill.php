<?php
require '../vendor/autoload.php';
require '../app/init.php';
$smmapi = new SMMApi();
//Enable refill status  
        
$refills = $conn->prepare("SELECT * FROM refill_status ");
$refills->execute(array());
$refills = $refills->fetchAll(PDO::FETCH_ASSOC);
foreach ($refills as $refill):
    
    $order_id_refill = $refill['order_id'];
    $refill_apiid = "$refill[refill_apiid]";
    
    $order  = $conn->prepare("SELECT * FROM orders WHERE order_id=:id ");
     $order  = $conn->prepare("SELECT * FROM orders INNER JOIN services ON services.service_id = orders.service_id INNER JOIN service_api ON services.service_api = service_api.id WHERE orders.order_id=:id ");
    $order ->execute(array("id"=>$order_id_refill));
    $order  = $order->fetch(PDO::FETCH_ASSOC);
    $order = json_decode(json_encode($order),true);

    $refill_apiurl = $order["api_url"]; 
     $get_refill_status    = $smmapi->action(array('key' =>$order["api_key"],'action' =>'refill_status','refill'=>$refill_apiid ),$refill_apiurl);
             
    $get_refill_status = json_decode(json_encode($get_refill_status),true);
    
       

    if(!empty($get_refill_status['status'])) :
      $new_refill_status = $get_refill_status['status'];
      $update  = $conn->prepare("UPDATE refill_status SET refill_status=:refill_status WHERE order_id=:id ");
        $update ->execute(array("id"=>$refill['order_id'] , "refill_status"=>$new_refill_status));
         

    endif;
    
     
    endforeach;
 

    
        header("Location:".site_url("crons/average.php"));