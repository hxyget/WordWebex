<?php include 'header.php'; ?>
<div class="container-fluid">
<div class=" row">
    <div class="col-md-4 col-sm-3 col-xs-4">
        <a data-toggle="tooltip" class="well top-block" href="/admin/clients">
            <img src="https://i.ibb.co/YQMWQdx/users.png" style="width:80px;" alt="users">

            <div>Total Members</div>
            <div><?php echo countRow(["table"=>"clients"]) ?></div>
        </a>
    </div>


    <div class="col-md-4 col-sm-3 col-xs-4">
        <a data-toggle="tooltip" class="well top-block" href="/admin/orders">
             <img src="https://i.ibb.co/TvBDTT0/order.png" style="width:80px;" alt="orders">

            <div>Orders</div>
            <div><?php echo countRow(["table"=>"orders"]) ?></div>
        </a>
    </div>



<div class="col-md-4 col-sm-3 col-xs-4">
        <a data-toggle="tooltip" class="well top-block" href="/admin/orders/1/fail">
             <img src="https://i.ibb.co/vZ9r5sz/failed-orders.png" style="width:80px;" alt="failed">


            <div>Failed Orders</div>
            <div><?php echo $failCount ?></div>
        </a>
    </div>

<?php
			if(countRow(["table"=>"refill_status"])>0){
			?>
     <div class="col-md-4 col-sm-3 col-xs-4">
        <a data-toggle="tooltip" class="well top-block" href="/admin/refill">
            <img src="https://i.ibb.co/KzzbJWT/refill.png" style="width:80px;" alt="refill">

            <div>Refills</div>
            <div><?php echo countRow(["table"=>"refill_status"] ) ?></div>
        </a>
    </div>
<?php			
			}else{			
			}		
			?>   
<?php
			if(countRow(["table"=>"orders","where"=>["order_where"=>api]])>0){
			?>
 <div class="col-md-4 col-sm-3 col-xs-4">
        <a data-toggle="tooltip" class="well top-block" href="/admin/apiorders">
           <img src="https://i.ibb.co/q7q9mZ4/reseller-order.png" style="width:80px;" alt="reseller">

            <div>Reseller Orders</div>
                        <div><?php echo countRow(["table"=>"orders","where"=>["order_where"=>api] ]) ?></div>
        </a>
    </div>
<?php			
			}else{			
			}		
			?>   
<?php
			if(countRow(["table"=>"orders","where"=>["api_orderid"=>0] ])>0){
			?>
    <div class="col-md-4 col-sm-3 col-xs-4">
        <a data-toggle="tooltip" class="well top-block" href="/admin/orders/1/all?mode=manuel">
            <img src="https://i.ibb.co/nPVFQWk/1006626-min.png" style="width:80px;" alt="manual">

            <div>Manual Orders</div>
            <div><?php echo countRow(["table"=>"orders","where"=>["api_orderid"=>0] ]) ?></div>
        </a></div>
<?php			
			}else{			
			}		
			?>   
    <?php
			if(countRow(["table"=>"childpanels"])>0){
			?>
    <div class="col-md-4 col-sm-3 col-xs-4">
        <a data-toggle="tooltip" class="well top-block" href="/admin/child-panels">
            <img src="https://i.ibb.co/nLXhtQB/child-panel.png" style="width:80px;" alt="child">

            <div>Child Panels</div>
            <div><?php echo countRow(["table"=>"childpanels"]) ?></div>
        </a>
    </div>
<?php			
			}else{			
			}		
			?>   
<?php
			if(countRow(["table"=>"tickets","where"=>["client_new"=>2] ])>0){
			?>
<div class="col-md-4 col-sm-3 col-xs-4">
        <a data-toggle="tooltip" class="well top-block" href="/admin/tickets?search=unread">
             <img src="https://i.ibb.co/41DPRDH/pending-tickets.png" style="width:80px;" alt="unread-tickets">

            <div>Unread Tickets</div>
            <div><?php echo countRow(["table"=>"tickets","where"=>["client_new"=>2] ]) ?></div>
        </a>
    </div>
<?php			
			}else{			
			}		
			?>   
<?php
			if(countRow(["table"=>"payments"])>0){
			?>
     <div class="col-md-4 col-sm-3 col-xs-4">
        <a data-toggle="tooltip" class="well top-block" href="/admin/payments">
             <img src="https://i.ibb.co/gMH73Bd/payments.png" style="width:80px;" alt="payments">

            <div>Payments</div>
            <div><?php echo countRow(["table"=>"payments"]) ?></div>
        </a>
    </div>
<?php			
			}else{			
			}		
			?>   
<?php
			if(countRow(["table"=>"tickets"])>0){
			?>
 <div class="col-md-4 col-sm-3 col-xs-4">
        <a data-toggle="tooltip" class="well top-block" href="/admin/tickets">
              <img src="https://i.ibb.co/TYXttRf/tickets.png" style="width:80px;" alt="tickets">


            <div>Support Tickets</div>
            <div><?php echo countRow(["table"=>"tickets"]); ?></div>
        </a>
    </div>
<?php			
			}else{			
			}		
			?>   
</div>


<div class="modal modal-center fade" id="confirmChange" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
   <div class="modal-dialog modal-dialog-center" role="document">
      <div class="modal-content">
         <div class="modal-body text-center">
            <h4>Are you sure you want to proceed ?</h4>
            <div align="center">
               <a class="btn btn-primary" href="" id="confirmYes">Yes</a>
               <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
         </div>
      </div>
   </div>
</div>

<?php include 'footer.php'; ?>
