<?php if( !route(3) ):
$pswimg = $theme["site_theme_alt"];
?>

        
<?php foreach($themes as $theme):
         
            $x = $theme['theme_dirname'];
            
            
         ?>
              <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="settings-themes__card settings-themes__card-active">
                                
                                <?php if( $settings["site_theme"] != $theme["theme_dirname"] ): ?>
                                <div class="settings-themes__card-preview" style="background-image: url(/img/psw_themecolor/<?=$theme["psw_img"]?><?=$settings["site_theme_alt"]?>.png)">
                                <?php endif;  
                                    
                                    if($_SESSION['theme']):
                                        
                                       
                                        
                                        endif;
                                    
                                    if( $settings["site_theme"] == $theme["theme_dirname"] ): echo '<div class="settings-themes__card-preview" style="background-image: url(/img/psw_themecolor/'.$theme["psw_img"].''.$settings["site_theme_alt"].'.png)"><span class="badge">Active</span>'; endif; ?>  
                                   
                                    <?php if( $settings["site_theme"] != $theme["theme_dirname"] ): ?>
                  <div class="settings-themes__card--activate">
                                            <a class="btn btn-primary" href="<?php echo site_url('admin/appearance/themes/active/'.$theme["id"]) ?>">Activate</a>                                        </div>
                  <?php endif; ?>
                                                                            
                                                   
                                                                    </div>
                                                                    <div class="settings-themes__card-title">
                                    <?php echo $theme["theme_name"]; ?>                                                  
                                </div>
                                
                                
                            </div>
                        </div>
         <?php endforeach; ?>
      </tbody>

   </table>
<br>
<br><br><br>


    



 <?php  if( $settings["site_theme"] == "Simplify" ):  ?>

<div class="col-md-8">
  <div class="panel panel-default">
    <div class="panel-body"> 
    <label class="control-label">Colours</label>
    
    
  <div class="row row-xs">

            <div class="col">
                <div class="card dwd-100">
                    <div class="card-body pd-20 table-responsive dof-inherit">
                        <div class="container-fluid pd-t-20 pd-b-20">
                            <ul class="nav nav-tabs pull-right dborder-0">
                                <li class="pull-right export-li">
                                    
                                </li>
                            </ul>
  
  
  <div class="table-responsive-md">
  <table class="table">
  <thead>
    <tr>
        <td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Red">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_1.0.png"></button>
      </form>
    </td>
    <td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Blue">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_2.0.png"></button>
      </form>
      </td><td>
    
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Lime">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_3.0.png"></button>
       
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Grapes">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_4.0.png"></button>
      </form></td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Dark">
           									
          
      
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_5.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Cyan">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_6.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Coral">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_7.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Green">
           									
          
          
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_8.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Grey">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_9.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Orange">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_10.0.png"></button>
      </form>
    </td><td>

<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Lilac">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/1/PSW_THEME_COLOUR_11.0.png"></button>
      </form>
    </td>
</tr>
    
    </thead></table>
    </div></div></div>


     <?php endif; ?>  
     
     
     
      
        

    

     

     
     
     
     
     
     
       <?php if( $settings["site_theme"] == "Eternity" ): ?>
 

     
     
     
<div class="col-md-8">
  <div class="panel panel-default">
    <div class="panel-body"> 
    <label class="control-label">Theme Colours</label>
    
    
  <div class="row row-xs">

            <div class="col">
                <div class="card dwd-100">
                    <div class="card-body pd-20 table-responsive dof-inherit">
                        <div class="container-fluid pd-t-20 pd-b-20">
                            <ul class="nav nav-tabs pull-right dborder-0">
                                <li class="pull-right export-li">
                                    
                                </li>
                            </ul>
  
  
  <div class="table-responsive-md">
  <table class="table">
  <thead>
    <tr>
        <td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 1.0">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_1.0.png"></button>
      </form>
    </td>
    <td>

    
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 2.0">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_2.0.png"></button>
       
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 3.0">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_3.0.png"></button>
      </form></td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 4.0">
           									
          
      
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_4.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 5.0">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_5.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 6.0">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_6.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 7.0">
           									
          
          
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_7.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 8.0">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_8.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 9.0">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_9.0.png"></button>
      </form>
    </td><td>

<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 10.0">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_10.0.png"></button>
      </form>
    </td>
</tr>
    
    </thead></table>
    </div></div></div>
     
     <br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label class="control-label">Active Theme Colour : <?=$settings[""]?> </label>
     <?php endif; ?>  
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     <!-- Engaging -->
     
     
     
     
      <?php if( $settings["site_theme"] == "Engaging" ): ?>
 

     
     
     
<div class="col-md-8">
  <div class="panel panel-default">
    <div class="panel-body"> 
    <label class="control-label">Theme Colours</label>
    
    
  <div class="row row-xs">

            <div class="col">
                <div class="card dwd-100">
                    <div class="card-body pd-20 table-responsive dof-inherit">
                        <div class="container-fluid pd-t-20 pd-b-20">
                            <ul class="nav nav-tabs pull-right dborder-0">
                                <li class="pull-right export-li">
                                    
                                </li>
                            </ul>
  
  
  <div class="table-responsive-md">
  <table class="table">
  <thead>
    <tr>
        <td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="ashgrey">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_1.0.png"></button>
      </form>
    </td>
    <td>

    
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="black">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_2.0.png"></button>
       
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="blue">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_3.0.png"></button>
      </form></td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 4.0">
           									
          
      
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_4.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 5.0">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_5.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="PSW THEME COLOUR 6.0">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/2/PSW_THEME_COLOUR_6.0.png"></button>
      </form>
    </td><td>

</tr>
    
    </thead></table>
    </div></div></div>
     
     <br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label class="control-label">Active Theme Colour : <?=$settings[""]?> </label>
     <?php endif; ?>  
     
     
     
     
     
     
     
     
     
     <!--end -->
     
     
     
     
     
     
     
     <!-- Clementine -->
     
      <?php if( $settings["site_theme"] == "Clementine" ): ?>
 
    
<div class="col-md-8">
  <div class="panel panel-default">
    <div class="panel-body"> 
    <label class="control-label">Theme Colours</label>
    
    
  <div class="row row-xs">

            <div class="col">
                <div class="card dwd-100">
                    <div class="card-body pd-20 table-responsive dof-inherit">
                        <div class="container-fluid pd-t-20 pd-b-20">
                            <ul class="nav nav-tabs pull-right dborder-0">
                                <li class="pull-right export-li">
                                    
                                </li>
                            </ul>
  
  
  <div class="table-responsive-md">
  <table class="table">
  <thead>
    <tr>
        <td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="parrot">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/Clementine/parrot.png"></button>
      </form>
    </td>
    <td>

    
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="green">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/Clementine/green.png"></button>
       
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="orange">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/Clementine/orange.png"></button>
      </form></td><td>
        
</tr>
    
    </thead></table>
    </div></div></div>
     
     <br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label class="control-label">Active Theme Colour : <?=$settings[""]?> </label>
     <?php endif; ?> 
     
     
     <!-- end -->
     
     
      
    
 <?php  if( $settings["site_theme"] == "Sale" ):  ?>

<div class="col-md-8">
  <div class="panel panel-default">
    <div class="panel-body"> 
    <label class="control-label">Colours</label>
    
    
  <div class="row row-xs">

            <div class="col">
                <div class="card dwd-100">
                    <div class="card-body pd-20 table-responsive dof-inherit">
                        <div class="container-fluid pd-t-20 pd-b-20">
                            <ul class="nav nav-tabs pull-right dborder-0">
                                <li class="pull-right export-li">
                                    
                                </li>
                            </ul>
  
  
  <div class="table-responsive-md">
  <table class="table">
  <thead>
    <tr>
        <td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Bootstrap">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_1.0.png"></button>
      </form>
    </td>
    <td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Cerulean">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_2.0.png"></button>
      </form>
      </td><td>
    
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Lightblue">
           									
          
         
       
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_3.0.png"></button>
       
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Sandstone">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_4.0.png"></button>
      </form></td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Slate">
           									
          
      
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_5.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Solar">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_6.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Lumen">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_7.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Spin">
           									
          
          
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_8.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Superhero">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_9.0.png"></button>
      </form>
    </td><td>
<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="United">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_10.0.png"></button>
      </form>
    </td><td>

<form action="" method="post" enctype="multipart/form-data">

          
        
          <input type="hidden" class="form-control" name="site_theme_alt" value="Flatly">
           									
          
        
        <button type="submit" class=""><img width="150" height="100" src="/img/psw_themecolor/4/PSW_THEME_COLOUR_11.0.png"></button>
      </form>
    </td>
</tr>
    
    </thead></table>
    </div></div></div>


     <?php endif; ?>   
     
     
     
     
     
     
     
     
     
    

 
 
<?php elseif( route(3) ): ?>
  <div class="col-md-12">
    <div class="panel">
      <div class="panel-heading edit-theme-title"><strong><?php echo $theme["theme_name"] ?></strong> edit the theme named</div>

        <div class="row">
          <div class="col-md-3 padding-md-right-null">

            <div class="panel-body edit-theme-body">
              <div class="twig-editor-block">
                <?php





                  $layouts  = [
                    "HTML"=>[
"header.twig","footer.twig","account.twig","addfunds.twig","api.twig","child-panels.twig",
                    "login.twig","neworder.twig","open_ticket.twig","orders.twig","refill.twig","signup.twig",
                    "services.twig","tickets.twig","refer.twig","dripfeeds.twig","subscriptions.twig",
                    "resetpassword.twig","setnewpassword.twig","updates.twig","blog.twig","blogpost.twig",
                    "terms.twig","faq.twig"],
                    "CSS"=>["bootstrap.css","style.css"],
                    "JS"=>["bootstrap.js","script.js"]
                  ];
                foreach ($layouts as $style => $layout):
                  echo '<div class="twig-editor-list-title" data-toggle="collapse" href="#folder_'.$style.'"><span class="fa fa-folder-open"></span>'.$style.'</div><ul class="twig-editor-list collapse in" id="folder_'.$style.'">';
                  foreach ($layouts[$style] as $layout) :
                    if( $lyt == $layout ):
                      $active = ' class="active file-modified" ';
                    else:
                      $active = '';
                    endif;
                    echo '
                      <li '. $active .'><a href="'.site_url('admin/appearance/themes/'.$theme["id"]).'?file='.$layout.'">'.$layout.'</a></li>';
                  endforeach;
                  echo '</ul>';
                endforeach;
              ?>
              </div>

            </div>
          </div>
          <div class="col-md-9 padding-md-left-null edit-theme__block-editor">
            <?php if( !$lyt ): ?>
              <div class="panel-body">
                <div class="row">
                   <div class="col-md-12">
                    <div class="theme-edit-block">
                      <div class="alert alert-info" role="alert">
                       Select a file from the left sidebar to start editing.
                      </div>
                    </div>
                  </div>
                  </div>
              </div>
            <?php else: ?>
                  
                  <div id="fullscreen">

               <div class="panel-body">

                <?php
                $file = fopen($fn, "r");
                $size = filesize($fn);
                $text = fread($file, $size); // -> Kodu okur
                $text = str_replace("<","&lt;",$text);
                $text = str_replace(">","&gt;",$text);
                $text = str_replace('"',"&quot;",$text);
                fclose($file); // -> Kapatır
                ?>

                <div class="row">
                    <div class="col-md-8">
                      <strong class="edit-theme-filename"><?=$dir."/".$lyt?></strong>
                        </div>
                        <div class="col-md-4 text-right">
                                    <a class="btn btn-xs btn-default fullScreenButton">
                                        <span class="glyphicon glyphicon-fullscreen"></span>
                                        Edit Full Screen </a>
                                </div>
                  </div>
           

                <form action="<?php echo site_url("admin/appearance/themes/".$theme["id"]."?file=".$lyt) ?>" method="post" class="twig-editor__form">
                  <textarea id="code" name="code" class="codemirror-textarea"><?=$text;?></textarea>
                  <div class="edit-theme-body-buttons text-right">
                      
                    <button class="btn btn-primary click">Save</button>
                  </div>
                </form>

              </div>
            <?php endif; ?>
          </div>
        </div>

    </div>
  </div>



<?php endif; ?>





    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/codemirror/3.20.0/codemirror.css">
      <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/codemirror/3.20.0/codemirror.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/codemirror/3.20.0/mode/xml/xml.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/codemirror/2.36.0/formatting.js"></script>