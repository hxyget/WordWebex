<?php include 'header.php'; ?>
<br>
<style>
.order-card {
    color: #fff;
}

.bg-c-blue {
    background: linear-gradient(to right, #493240, #f09) !important;
}

.bg-c-green {
    background: linear-gradient(to right, #373b44, #4286f4) !important;
}

.bg-c-yellow {
    background: linear-gradient(to right, #0a504a, #38ef7d) !important;
}

.bg-c-pink {
    background: linear-gradient(to right, #a86008, #ffba56) !important;
}


.card {
    border-radius: 19px;
    -webkit-box-shadow: 0 1px 2.94px 0.06px rgba(4,26,55,0.16);
    box-shadow: 0 1px 2.94px 0.06px rgba(4,26,55,0.16);
    border: none;
    margin-bottom: 30px;
    -webkit-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
}

.card .card-block {
    border-radius: 19px;
    padding: 25px;
    box-shadow: 0 0.46875rem 2.1875rem rgba(90,97,105,0.1), 0 0.9375rem 1.40625rem rgba(90,97,105,0.1), 0 0.25rem 0.53125rem rgba(90,97,105,0.12), 0 0.125rem 0.1875rem rgba(90,97,105,0.1);

}

.order-card i {
    font-size: 26px;
}

.f-left {
    float: left;
}

.f-right {
    float: right;
}  
</style>



<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
<div class="container">
    <div class="row">
        <div class="col-md-4 col-xl-3">
            <a href="/admin/clients" data-toggle="tooltip">
            <div class="card bg-c-blue order-card">
                <div class="card-block" >
                    <h6 class="m-b-20">Total Members</h6>
                    <h2 class="text-right" style="padding-bottom:20px;"><img src="https://i.ibb.co/YQMWQdx/users.png" style="width:80px;" class="f-left" alt="users"><span><?php echo countRow(["table"=>"clients"]) ?></span></h2>
                    
                </div>
            </div>
            </a> 
        </div>
        
        <div class="col-md-4 col-xl-3">
            <a href="/admin/orders" data-toggle="tooltip">
            <div class="card bg-c-green order-card">
                <div class="card-block">
                    <h6 class="m-b-20">Orders Received</h6>
                    <h2 class="text-right"><i class="fa fa-rocket f-left"></i><span><?php echo countRow(["table"=>"orders"]) ?></span></h2>
                    <p class="m-b-0">Failed Orders<span class="f-right"><?php echo $failCount ?></span></p>
                </div>
            </div>
            </a>
        </div>
        
        
        <div class="col-md-4 col-xl-3">
            <a href="/admin/refill" data-toggle="tooltip">
            <div class="card bg-c-pink order-card">
                <div class="card-block">
                    <h6 class="m-b-20">Refills</h6>
                    <h2 class="text-right" style="padding-bottom:20px;"><img src="https://i.ibb.co/KzzbJWT/refill.png" style="width:80px;" class="f-left" alt="users"><span><?php echo countRow(["table"=>"refill_status"] ) ?></span></h2>
                </div>
            </div>
            </a>
        </div>
        
  </div>
    <div class="row">
        <div class="col-md-4 col-xl-3">
            <a href="/admin/apiorders" data-toggle="tooltip">
            <div class="card bg-c-yellow order-card">
                <div class="card-block">
                    <h6 class="m-b-20">Reseller Orders</h6>
                    <h2 class="text-right" style="padding-bottom:20px;"><img src="https://i.ibb.co/q7q9mZ4/reseller-order.png" style="width:80px;" class="f-left" alt="users"><span><?php echo countRow(["table"=>"orders","where"=>["order_where"=>api] ]) ?></span></h2>
                    
                </div>
            </div>
            </a>
        </div>
        <div class="col-md-4 col-xl-3">
            <a href="/admin/admin/orders/1/all?mode=manuel" data-toggle="tooltip">
            <div class="card bg-c-blue order-card">
                <div class="card-block" >
                    <h6 class="m-b-20">Manual Orders</h6>
                    <h2 class="text-right" style="padding-bottom:20px;"><img src="https://i.ibb.co/nPVFQWk/1006626-min.png" style="width:80px;" class="f-left" alt="users"><span><?php echo countRow(["table"=>"orders","where"=>["api_orderid"=>0] ]) ?></span></h2>
                    
                </div>
            </div>
            </a> 
        </div>
        
        
        
        <div class="col-md-4 col-xl-3">
            <a href="/admin/child-panels" data-toggle="tooltip">
            <div class="card bg-c-green order-card">
                <div class="card-block">
                    <h6 class="m-b-20">Child Panels</h6>
                    <h2 class="text-right" style="padding-bottom:20px;"><img src="https://i.ibb.co/nLXhtQB/child-panel.png" style="width:80px;" class="f-left" alt="users"><span><?php echo countRow(["table"=>"childpanels"]) ?></span></h2>
                </div>
            </div>
            </a>
        </div>
        
  </div>
  
  
    <div class="row">
        <div class="col-md-4 col-xl-3">
            <a href="/admin/tickets?search=unread" data-toggle="tooltip">
            <div class="card bg-c-pink order-card">
                <div class="card-block">
                    <h6 class="m-b-20">Unread Tickets</h6>
                    <h2 class="text-right" style="padding-bottom:20px;"><img src="https://i.ibb.co/41DPRDH/pending-tickets.png" style="width:80px;" class="f-left" alt="users"><span><?php echo countRow(["table"=>"tickets","where"=>["client_new"=>2] ]) ?></span></h2>
                    
                </div>
            </div>
            </a>
        </div>
        <div class="col-md-4 col-xl-3">
            <a href="/admin/payments" data-toggle="tooltip">
            <div class="card bg-c-yellow order-card">
                <div class="card-block" >
                    <h6 class="m-b-20">Payments</h6>
                    <h2 class="text-right" style="padding-bottom:20px;"><img src="https://i.ibb.co/gMH73Bd/payments.png" style="width:80px;" class="f-left" alt="users"><span><?php echo countRow(["table"=>"payments"]) ?></span></h2>
                    
                </div>
            </div>
            </a> 
        </div>
        
        
        
        <div class="col-md-4 col-xl-3">
            <a href="/admin/tickets" data-toggle="tooltip">
            <div class="card bg-c-blue order-card">
                <div class="card-block">
                    <h6 class="m-b-20">Support Tickets</h6>
                    <h2 class="text-right" style="padding-bottom:20px;"><img src="https://i.ibb.co/TYXttRf/tickets.png" style="width:80px;" class="f-left" alt="users"><span><?php echo countRow(["table"=>"tickets"]); ?></span></h2>
                </div>
            </div>
            </a>
        </div>
        
  </div>
  </div>
</div>
<?php include 'footer.php'; ?>
