<?php

namespace Coinbase\Wallet\Exception;

class ExpiredTokenException extends UnauthorizedException
{
}
