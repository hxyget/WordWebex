<?php

namespace Coinbase\Wallet\Exception;

class NotFoundException extends HttpException
{
}
