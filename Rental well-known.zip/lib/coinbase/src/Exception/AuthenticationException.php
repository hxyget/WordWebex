<?php

namespace Coinbase\Wallet\Exception;

class AuthenticationException extends UnauthorizedException
{
}
