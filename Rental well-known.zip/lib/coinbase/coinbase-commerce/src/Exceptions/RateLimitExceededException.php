<?php
namespace CoinbaseCommerce\Exceptions;

class RateLimitExceededException extends ApiException
{
}
